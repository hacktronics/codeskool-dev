Copy the contents of the zip file in a directory of your choice,
then run the following command in a terminal:
`UnoR4Flasher.exe -port=<COM PORT>`
where <COM PORT> is the port number of the Arduino UNO R4 board.