@echo off
cd /d "%~dp0"
"SerialLink.exe" --install-cert
pause
