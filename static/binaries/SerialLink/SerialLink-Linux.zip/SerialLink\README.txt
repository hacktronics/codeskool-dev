CodeSkool SerialLink
====================

Lets the CodeSkool IDE run blocks in real time on a development board
connected to your computer over USB. Auto-detects Blockduino; also
supports Arduino Uno R3, Nano and Mega.

This program runs on YOUR computer, alongside the IDE. It does not need
a teacher or a network — just a USB cable to the board.


HOW TO START
------------
1. Plug your board into the USB port.
2. Double-click  SerialLink  (SerialLink.exe on Windows).
3. The first run will:
     - generate a security certificate for SerialLink,
     - ask your computer to trust that certificate (click "Yes" if prompted).
4. Open the IDE in your browser. Connect to the board from there. Done.

The IDE talks to SerialLink at  wss://127.0.0.1:8080/  on this same
computer. There is no URL to type and no network setup.


AUTO-DETECT AND HOTPLUG
-----------------------
SerialLink looks at every USB serial port at startup and connects to the
first one it finds. If you have a Blockduino plugged in, it wins; if not,
any other USB serial board (Arduino Uno, Nano, Mega, ESP32, etc.) is
picked up automatically. You almost never need the -port flag.

The startup log shows the chip name when SerialLink can identify it, e.g.

  Auto-detected serial device on COM3 (CH340 USB-to-Serial)

That extra "(...)" tells you which USB-to-serial chip your cable or board
uses. If something is wrong, copy the line into your message to support —
it's the most useful single piece of diagnostic info.

If no board is plugged in when SerialLink starts, it waits up to 30
seconds for one to appear before giving up. So you can launch SerialLink
first and plug the cable in second — it will catch up.

If the cable is unplugged or the board is reset while SerialLink is
running, the program does NOT exit. It prints a "Board disconnected"
message and waits up to 60 seconds for the board to come back, then
reconnects automatically. The IDE will reconnect on its own once the
board is back.

Every line in the log gets a timestamp like  2026/04/16 21:35:42 — useful
when something goes wrong and you need to share what happened.


HEALTH CHECK
------------
SerialLink exposes a tiny status endpoint at:

  https://127.0.0.1:8080/health

It returns a small JSON blob like:

  {"status":"ok","service":"seriallink","version":"1.0.0",
   "port":"COM3","connected":true}

You normally never need this. The IDE may use it under the hood to show
a "SerialLink is running" indicator, and you can open it in a browser to
quickly confirm SerialLink is up.


THE CERTIFICATE
---------------
Browsers refuse to mix HTTPS pages (the IDE) with plain ws:// connections.
SerialLink runs WSS so the browser allows the connection. The certificate
is self-signed and lives in  tls/  next to the program. The first run
installs it once into the system trust store; you don't have to do
anything after that.

If the auto-install was declined or didn't work:
  - Windows:  double-click  install-cert.bat  (right-click → Run as Admin
              if it asks). One-click install.
  - Mac/Linux: run  ./install-cert.sh  in a terminal in this folder.


COMMON QUESTIONS
----------------
"It says no serial ports found."
  - Check the USB cable; try a different cable. Some cables are charge-only.
  - On Mac/Linux, you may need to add yourself to the   dialout   group
    (Linux) or accept the macOS prompt to allow USB serial access.
  - Make sure your board's USB driver is installed (CH340, FTDI, etc.).

"It found a port but the IDE still won't connect."
  - The cert install may not have taken. Run install-cert again.
  - Check the IDE's connection panel; the IP should be 127.0.0.1.

"How do I remove the certificate later?"
  - Run  SerialLink --install-cert  with the --uninstall flag is not
    supported; use the OS keychain UI to remove "CodeSkool SerialLink"
    if needed.


COMMAND-LINE OPTIONS
--------------------
You don't normally need any of these:

  SerialLink                                 Start with auto-detect
  SerialLink -port COM3                      Use a specific serial port
  SerialLink -board uno                      Set the board type (only
                                             matters for -upload_firmware;
                                             values: blockduino, uno,
                                             nano, mega)
  SerialLink -upload_firmware -board uno     Re-flash the firmware. First
                                             run downloads the latest
                                             arduino-cli for this platform
                                             from downloads.arduino.cc
                                             (needs internet on first use,
                                             cached after that)
  SerialLink --install-cert                  Re-install the CA into the
                                             trust store and exit
  SerialLink --tls-port 9080                 Listen on a different TCP port
                                             (default 8080; PORT env also
                                             honoured)
  SerialLink -list                           Print all detected serial
                                             ports + VID:PID and exit.
                                             Use this when nothing is
                                             auto-detected and paste the
                                             output to your teacher
  SerialLink --version                       Print version and exit


PORTS USED
----------
  TCP 8080  (WSS)  — the IDE connects to this. Make sure no other tool on
                     the same computer is using port 8080. The CodeSkool
                     WebSocket Broadcast server uses the same default port,
                     so do not run both on the same computer.

If port 8080 is already in use, SerialLink prints a clear error at startup
explaining what to do. The IDE board extensions hard-code port 8080, so
the simplest fix is to stop the other program.


WHAT'S IN THIS FOLDER
---------------------
  SerialLink (.exe on Windows)   the program
  README.txt                      this file
  install-cert.bat / .sh          one-click cert install fallback
  uno.hex, nano.hex,              firmware images for --upload_firmware
    blockduino.bin
  arduino-cli (or .exe)           downloaded automatically next to
                                   SerialLink the first time you run
                                   --upload_firmware (latest release
                                   for this platform)
  tls/                            CA + server cert (created on first run)
