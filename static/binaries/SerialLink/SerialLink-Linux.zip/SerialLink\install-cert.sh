#!/bin/bash
cd "$(dirname "$0")"
./SerialLink --install-cert
