#!/bin/bash
cd "$(dirname "$0")"
./codeskool-broadcast --install-cert
