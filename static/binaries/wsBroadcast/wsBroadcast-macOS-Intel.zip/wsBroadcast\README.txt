CodeSkool WebSocket Broadcast Server
====================================

A small server that lets several Scratch projects share messages in real
time. Use it for multiplayer games, chat, shared whiteboards — anything
where one project needs to tell other projects what's going on.

One person runs the server (the HOST). Everyone else who wants to join
the room is a PLAYER. Players connect from their Scratch projects with
the Web Sockets extension.

WHAT'S INSIDE
-------------
  host/    The broadcast server. Stays on the host's computer.
  player/  A small one-time setup tool. Copy this folder onto every
           player's computer before they join for the first time.


HOST - HOW TO START
-------------------
1. Open the host/ folder.
2. Double-click  codeskool-broadcast  (codeskool-broadcast.exe on Windows).
3. The first run will:
     - generate a security certificate for your server,
     - ask your computer to trust that certificate (click "Yes" if prompted),
     - print the address players will type into their Scratch project,
       e.g.   wss://192.168.1.50:8080/
     - print a FINGERPRINT (four short pairs of letters/numbers, like AB:CD:EF:12).
4. Share the address and the fingerprint with the players (write them on
   a board, paste in chat, however).

In Scratch, players drop a   connect [URL]   block from the Web Sockets
extension and paste your URL into it. Once connected, every project in
the room receives every  send  message broadcast by the others.


PLAYERS - HOW TO JOIN (ONCE PER COMPUTER)
-----------------------------------------
1. Each player gets a copy of the  player/  folder
   (USB stick, shared folder, email, Google Drive — any way works).
2. The player opens that folder and reads  player/README.txt.
   It walks them through running cert-installer once.
3. After the cert is installed, the player opens any Scratch project that
   uses the Web Sockets extension and pastes the   wss://...   URL into
   the connect block. No browser warnings.

Players only need to do step 1 and 2 the first time. After that they
just open Scratch and connect.


WHAT THE FINGERPRINT IS FOR
---------------------------
The player's installer will show the same fingerprint your server prints.
Read your fingerprint out loud (or share it in chat); the player checks
each pair matches. If anything is different, someone else is pretending
to be your server — do not install.


YOUR DATA
---------
The CA certificate and per-startup server certificate live in the  data/
folder created next to the server program. The server keeps no message
history — broadcasts are forwarded and forgotten. Back up data/ if you
want to keep the same CA after moving to a different computer (so players
do not have to re-run cert-installer).


COMMON QUESTIONS
----------------
"Players can't reach the URL."
  - Check Windows Firewall / your router. The host computer and the
    player computers must be on the same Wi-Fi or LAN.
  - Make sure you are using the IP address (wss://192.168...) and not
    the word "localhost" — localhost only works on the host computer.

"I changed Wi-Fi networks and the URL stopped working."
  - Just restart the server. It picks up the new IP and re-issues a
    matching certificate. Players keep their installed cert; nothing on
    their side has to change.

"The browser still says 'not secure' / connect block fails immediately."
  - The certificate install was declined or did not run.
  - On the host computer:  double-click host/install-cert.bat
    (Windows) or run  host/install-cert.sh  on Mac/Linux.
  - On a player computer:  re-run player/cert-installer.

"How do I remove the certificate later?"
  - Run  cert-installer --uninstall  on the player computer.


ADVANCED: COMMAND-LINE OPTIONS
------------------------------
The server runs with sensible defaults — just double-click and go. If
you need to change something, open a terminal (Command Prompt on Windows,
Terminal on Mac/Linux), cd into the host folder, and run:

  codeskool-broadcast --port 9000
      Listen on port 9000 instead of the default 8080. Useful if 8080 is
      already in use on this computer (a common port — many other tools
      grab it), or if your network has opened a different port through
      the firewall. The URL you share changes to match
      (e.g. wss://192.168.1.50:9000/).

  codeskool-broadcast --data D:\my-broadcast-data
      Store the CA in a different folder. Default is ./data next to the
      program. Useful if you want to keep the same CA across reinstalls
      or move the server to a different computer without players
      re-trusting.

  codeskool-broadcast --install-cert
      Re-install the CA into this computer's trust store and exit. Run
      this if the first-run auto-install was declined. Same as
      double-clicking install-cert.bat.

  codeskool-broadcast --help
      Show all options.

You can also set the  PORT  environment variable instead of using --port.

EXAMPLES

  Windows Command Prompt:
      cd "C:\path\to\host"
      codeskool-broadcast.exe --port 9000

  Mac / Linux Terminal:
      cd /path/to/host
      ./codeskool-broadcast --port 9000 --data ~/broadcast-data


CHANGING THE PORT
-----------------
If you change the port, two things change at once:
  1. The URL you share with players:               wss://YOUR_IP:NEW_PORT/
  2. The URL players type into  cert-installer:    https://YOUR_IP:NEW_PORT

The CA fingerprint and everything else stay the same.
