Broadcast Certificate Setup
===========================

Run this ONCE on this computer, then your Scratch project can connect
to the broadcast server.

You will need:
  - The broadcast URL the host shared with you
    (something like   wss://192.168.1.50:8080/   or
                      https://192.168.1.50:8080   )
  - The fingerprint the host will share
    (four short pairs of letters/numbers, like   AB:CD:EF:12  )


WINDOWS
-------
1. Double-click  cert-installer.exe
2. A window opens. Type or paste the URL when asked. Either form works
   (wss:// or https://).
3. The window shows a fingerprint (four pairs of letters/numbers,
   like  AB:CD:EF:12  ).
4. Check that all four pairs match what the host has on screen.
   If anything is different, type  no  and tell the host.
5. Type  y  and press Enter.
6. If Windows asks "Do you want to allow this app to make changes?",
   click  Yes.
7. When it says SUCCESS, close the window. Done.


MAC
---
1. Open the Terminal app (search for "Terminal" in Spotlight).
2. Drag  cert-installer  into the Terminal window and press Enter.
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your Mac password when asked, press Enter.
5. When it says SUCCESS, close the Terminal. Done.


LINUX
-----
1. Open a terminal in this folder.
2. Run    ./cert-installer
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your password when asked.
5. When it says SUCCESS, you are done.


CONNECTING FROM SCRATCH
-----------------------
After SUCCESS:
  - Open Scratch and your project.
  - Add the Web Sockets extension if you haven't already.
  - In the   connect [URL]   block, paste the   wss://...   URL the host
    shared with you.
  - Use the   on socket open  ,   send  ,  and   on message received
    blocks to talk to the other projects in the room.

You only have to do the certificate step once per computer.


TO REMOVE THE CERTIFICATE LATER
-------------------------------
  Windows:    cert-installer.exe --uninstall
  Mac/Linux:  ./cert-installer --uninstall


ALL COMMAND-LINE OPTIONS
------------------------
You don't normally need any of these — the program asks you everything
when you run it. They are here in case the host tells you to use one.

  cert-installer
      Run interactively. Asks for the URL and confirmation.

  cert-installer --server https://192.168.1.50:8080
      Use this URL straight away without asking. Still shows the
      fingerprint and asks you to confirm before installing.

  cert-installer --uninstall
      Remove the certificate. No URL needed.

  cert-installer --help
      Show all options.
