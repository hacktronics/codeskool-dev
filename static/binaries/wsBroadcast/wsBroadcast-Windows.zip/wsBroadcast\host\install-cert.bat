@echo off
cd /d "%~dp0"
"codeskool-broadcast.exe" --install-cert
pause
