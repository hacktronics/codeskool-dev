CodeSkool Bridge
================

Compiles and uploads Arduino-style code from the CodeSkool IDE to real
hardware over USB. Supports Arduino Uno R3 / R4 / Nano / Mega, ESP32,
ESP32-C3, and Raspberry Pi Pico 2 / W.


WHAT'S INSIDE
-------------
  teacher/   The bridge server. Stays on the teacher's computer.
             (Or on YOUR computer, if you are using this at home.)
  student/   A small one-time setup tool. Only needed if you are
             running the bridge as a classroom server that other
             students will connect to.


WHEN YOU NEED EACH FOLDER
-------------------------
HOME USE / SINGLE COMPUTER (most kids):
  Use only the   teacher/   folder. Run codeskool-bridge there. The
  IDE on the same computer talks to it on   wss://127.0.0.1:8443/ws  .
  No   student/   folder. No cert-installer. No URL changes in the IDE.
  Just double-click and go.

CLASSROOM USE / SHARED BRIDGE:
  Teacher: Run the bridge from the   teacher/   folder on YOUR computer.
  Students: Copy the   student/   folder onto each student computer
  and run cert-installer once. Then in the IDE,
    Settings > Bridge > Server Settings
  and paste the   wss://TEACHER_IP:8443/ws   URL the teacher's screen
  shows at startup.


TEACHER - HOW TO START
----------------------
1. Open the teacher/ folder.
2. Double-click  codeskool-bridge  (codeskool-bridge.exe on Windows).
3. The first run will:
     - download Arduino CLI and required board cores + libraries
     - generate a security certificate for your bridge
     - ask your computer to trust that certificate (click "Yes" if prompted)
     - print the URL students will paste:
         wss://192.168.1.50:8443/ws       (your IP, your port)
     - print a FINGERPRINT (four pairs of letters/numbers, like AB:CD:EF:12).
4. Share the URL and the fingerprint with students. Write it on the board.

Students will paste the URL into  Settings > Bridge > Server Settings
inside the IDE.


STUDENTS - HOW TO JOIN (ONCE PER COMPUTER)
------------------------------------------
1. Copy the  student/  folder onto each student computer.
2. The student opens that folder and reads  student/README.txt.
   It walks them through running cert-installer once. They confirm the
   fingerprint matches the teacher's screen.
3. After install, in the IDE:
   Settings > Bridge > Server Settings   →   paste the teacher's URL.
4. Compile + upload from blocks now goes through the teacher's bridge.

Students only do steps 1, 2, 3 the first time. After that, the IDE
remembers the URL.


WHAT THE FINGERPRINT IS FOR
---------------------------
The student's installer shows the same fingerprint your bridge prints.
Read your fingerprint out loud; the student checks each pair matches.
If anything is different, do not install — someone else is pretending
to be your bridge.


YOUR DATA
---------
The CA, server cert, Arduino CLI, board cores and libraries all live
in folders next to the bridge program (tls/, arduino-cli/, arduino-cache/,
arduino-data/, arduino-user/). To move the bridge to a new computer
without students re-trusting, copy the  tls/  folder along with the
binary.


COMMON QUESTIONS
----------------
"At home, do I need the student/ folder or cert-installer?"
  - No. Single-machine use needs neither. The IDE talks to localhost,
    the CA was auto-installed when the bridge first started, you are
    done.

"Students can't reach the URL."
  - Check Windows Firewall / your router. The teacher computer and the
    student computers must be on the same Wi-Fi or LAN.
  - The URL must be the IP form (wss://192.168...) — "localhost" only
    works on the teacher's own computer.

"I changed Wi-Fi networks and the URL stopped working."
  - Restart the bridge. It picks up the new IP and re-issues a matching
    server cert. Students keep their installed CA — nothing changes on
    their side. They just need the new URL.

"The IDE says 'bridge not running' but it is."
  - Open Settings > Bridge > Server Settings and confirm the URL points
    at the right machine and port. The default is wss://127.0.0.1:8443/ws.

"How do I remove the certificate later?"
  - On a student computer:  cert-installer --uninstall
  - On the teacher computer: there is no separate uninstall command,
    but you can re-run with  codeskool-bridge --install-cert  to refresh.


ADVANCED: COMMAND-LINE OPTIONS
------------------------------
Most people don't need these — just double-click. If you need to:

  codeskool-bridge --port 9443
      Listen on port 9443 instead of 8443. Useful if 8443 is taken.
      The URL students enter changes accordingly.

  codeskool-bridge --install-cert
      Re-install the CA into this computer's trust store and exit.
      Same as double-clicking install-cert.bat.

  codeskool-bridge --help
      Show all options.

You can also set the  PORT  environment variable instead of --port.


POWER USERS: BROWSER OVERRIDE
-----------------------------
The IDE persists the bridge URL in the browser as
  localStorage.CODESKOOL_BRIDGE_URL
You can set or reset it from the browser developer console (F12):
  localStorage.setItem('CODESKOOL_BRIDGE_URL', 'wss://192.168.1.50:8443/ws')
  localStorage.removeItem('CODESKOOL_BRIDGE_URL')   // back to default
The Settings > Bridge > Server Settings dialog writes to the same key.
