#!/bin/bash
cd "$(dirname "$0")"
./codeskool-bridge --install-cert
