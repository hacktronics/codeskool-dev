Bridge Certificate Setup
========================

Run this ONCE on this computer if you are joining a classroom bridge
that runs on the teacher's computer. After that, your IDE can compile
and upload through the teacher's bridge.

If you are running the bridge yourself on this same computer, you do
NOT need this — skip everything and just double-click the bridge in
the   teacher/   folder.

You will need:
  - The bridge URL the teacher wrote on the board
    (something like   wss://192.168.1.50:8443/ws   or
                      https://192.168.1.50:8443   )
  - The fingerprint the teacher will read out
    (four short pairs of letters/numbers, like   AB:CD:EF:12  )


WINDOWS
-------
1. Double-click  cert-installer.exe
2. A window opens. Type or paste the URL when asked.
3. The window shows a fingerprint (four pairs of letters/numbers,
   like  AB:CD:EF:12  ).
4. Check that all four pairs match what the teacher has on screen.
   If anything is different, type  no  and tell the teacher.
5. Type  y  and press Enter.
6. If Windows asks "Do you want to allow this app to make changes?",
   click  Yes.
7. When it says SUCCESS, close the window.


MAC
---
1. Open the Terminal app (search for "Terminal" in Spotlight).
2. Drag  cert-installer  into the Terminal window and press Enter.
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your Mac password when asked.
5. When it says SUCCESS, close the Terminal.


LINUX
-----
1. Open a terminal in this folder.
2. Run    ./cert-installer
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your password when asked.
5. When it says SUCCESS, you are done.


CONNECTING THE IDE
------------------
After SUCCESS:
  - Open the CodeSkool IDE.
  - In the menu, go to:
      Settings  >  Bridge  >  Server Settings
  - Paste the teacher's   wss://...   URL into the box and click Save.

Now compile and upload from blocks goes through the teacher's bridge.
You only need to do these steps once per computer.


TO REMOVE THE CERTIFICATE LATER
-------------------------------
  Windows:    cert-installer.exe --uninstall
  Mac/Linux:  ./cert-installer --uninstall


ALL COMMAND-LINE OPTIONS
------------------------
Normally you don't need any of these — the program asks you everything.

  cert-installer
      Run interactively. Asks for the URL and confirmation.

  cert-installer --server https://192.168.1.50:8443
      Use this URL straight away. Still shows the fingerprint and asks
      you to confirm before installing.

  cert-installer --uninstall
      Remove the certificate.

  cert-installer --help
      Show all options.
