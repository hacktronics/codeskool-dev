@echo off
cd /d "%~dp0"
"codeskool-bridge.exe" --install-cert
pause
