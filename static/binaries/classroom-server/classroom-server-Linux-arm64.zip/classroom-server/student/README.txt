Classroom Certificate Setup
===========================

Run this ONCE on this computer, then you can join your classroom.

You will need:
  - The classroom URL your teacher wrote on the board
    (something like   https://192.168.1.50:8080  )
  - The fingerprint your teacher will read out
    (four short pairs of letters/numbers, like   AB:CD:EF:12  )


WINDOWS
-------
1. Double-click  cert-installer.exe
2. A window opens. Type or paste the classroom URL when asked.
3. The window shows a fingerprint (four pairs of letters/numbers,
   like  AB:CD:EF:12  ).
4. Check that all four pairs match what your teacher has on screen.
   If anything is different, type  no  and tell your teacher.
5. Type  y  and press Enter.
6. If Windows asks "Do you want to allow this app to make changes?",
   click  Yes.
7. When it says SUCCESS, close the window. Done.


MAC
---
1. Open the Terminal app (search for "Terminal" in Spotlight).
2. Drag  cert-installer  into the Terminal window and press Enter.
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your Mac password when asked, press Enter.
5. When it says SUCCESS, close the Terminal. Done.


LINUX
-----
1. Open a terminal in this folder.
2. Run    ./cert-installer
3. Type the URL when asked, check the fingerprint, type  y .
4. Type your password when asked.
5. When it says SUCCESS, you are done.


JOINING THE CLASSROOM
---------------------
After SUCCESS:
  - Open your browser.
  - Go to the URL your teacher wrote on the board.
  - Type the class code your teacher gave you.

You only have to do the certificate step once per computer.


TO REMOVE THE CERTIFICATE LATER
-------------------------------
  Windows:    cert-installer.exe --uninstall
  Mac/Linux:  ./cert-installer --uninstall


ALL COMMAND-LINE OPTIONS
------------------------
You don't normally need any of these - the program asks you everything
when you run it. They are here in case your teacher tells you to use one.

  cert-installer
      Run interactively. Asks for the URL and confirmation.

  cert-installer --server https://192.168.1.50:8080
      Use this URL straight away without asking. Still shows the
      fingerprint and asks you to confirm before installing.

  cert-installer --uninstall
      Remove the certificate. No URL needed.

  cert-installer --help
      Show all options.
