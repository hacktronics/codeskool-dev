#!/bin/bash
cd "$(dirname "$0")"
./codeskool-classroom --install-cert
