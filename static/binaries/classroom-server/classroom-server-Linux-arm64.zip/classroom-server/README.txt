CodeSkool Classroom Server
==========================

This zip contains everything you need to run a CodeSkool classroom on your
own computer (no internet required after install).

WHAT'S INSIDE
-------------
  teacher/   The classroom server. Stays on the teacher's computer.
  student/   A small one-time setup tool. Copy this folder onto every
             student computer before its first use.


TEACHER - HOW TO START
----------------------
1. Open the teacher/ folder.
2. Double-click  codeskool-classroom  (codeskool-classroom.exe on Windows).
3. The first run will:
     - generate a security certificate for your classroom,
     - ask your computer to trust that certificate (click "Yes" if prompted),
     - print the address students will type, e.g.   https://192.168.1.50:8080
     - print a FINGERPRINT (four short pairs of letters/numbers, like AB:CD:EF:12).
4. Open the address in your browser to see the dashboard and create your
   first classroom.

Write the address and the fingerprint on the board. Students will need both.


STUDENTS - HOW TO JOIN (ONCE PER COMPUTER)
------------------------------------------
1. Copy the  student/  folder onto each student computer
   (USB stick, shared folder, email - any way works).
2. The student opens that folder and reads  student/README.txt.
   It walks them through running cert-installer once.
3. After the cert is installed, the student just opens the URL you wrote
   on the board in their browser. No more warnings.

Students only need to do step 1 and 2 the first time. After that, they
visit the URL directly.


WHAT THE FINGERPRINT IS FOR
---------------------------
The student's installer will show the same fingerprint your server prints.
Read your fingerprint out loud; the student checks each pair matches.
If anything is different, someone else is pretending to be your server -
do not install.


YOUR DATA
---------
Everything (classrooms, students, projects, files) lives in the  data/
folder created next to the server program. Back that folder up if you
want to keep your classrooms safe.


COMMON QUESTIONS
----------------
"My students can't reach the URL."
  - Check Windows Firewall / your router. The teacher computer and the
    student computers must be on the same Wi-Fi or LAN.
  - Make sure you are using the IP address (https://192.168...) and not
    the word "localhost" - localhost only works on the teacher computer.

"I changed Wi-Fi networks and the URL stopped working."
  - Just restart the server. It picks up the new IP and re-issues a
    matching certificate. Students keep their installed cert; nothing on
    their side has to change.

"The browser still says 'not secure'."
  - The certificate install was declined or did not run.
  - On the teacher computer:  double-click teacher/install-cert.bat
    (Windows) or run  teacher/install-cert.sh  on Mac/Linux.
  - On a student computer:  re-run student/cert-installer.

"How do I remove the certificate later?"
  - Run  cert-installer --uninstall  on the student computer.
  - The teacher can do the same with  codeskool-classroom --install-cert
    (re-install) - there is no separate uninstall command on the server,
    but the same certutil / security commands work manually.


ADVANCED: COMMAND-LINE OPTIONS
------------------------------
The server runs with sensible defaults - just double-click and go. If you
need to change something, open a terminal (Command Prompt on Windows,
Terminal on Mac/Linux), cd into the teacher folder, and run:

  codeskool-classroom --port 9000
      Listen on port 9000 instead of the default 8080. Useful if 8080 is
      already in use on this computer, or if your school IT has opened a
      different port through the firewall. The URL you write on the board
      will change to match (e.g. https://192.168.1.50:9000).

  codeskool-classroom --data D:\my-classroom-data
      Store classrooms, students, projects and the CA in a different folder.
      Default is ./data next to the program. Useful if you want to keep your
      data on a different drive or back it up to a specific location.

  codeskool-classroom --install-cert
      Re-install the CA into this computer's trust store and exit. Run this
      if the first-run auto-install was declined or if you reset your
      Windows / Mac trust store. Same as double-clicking install-cert.bat.

  codeskool-classroom --help
      Show all options.

You can also set the  PORT  environment variable instead of using --port.

EXAMPLES

  Windows Command Prompt:
      cd "C:\path\to\teacher"
      codeskool-classroom.exe --port 9000

  Mac / Linux Terminal:
      cd /path/to/teacher
      ./codeskool-classroom --port 9000 --data ~/classroom-data


CHANGING THE PORT
-----------------
If you change the port, three things change at once:
  1. The URL on the board:        https://YOUR_IP:NEW_PORT
  2. The URL students enter into  cert-installer:  same URL
  3. The dashboard URL you open:  https://localhost:NEW_PORT

The CA fingerprint and everything else stay the same.
