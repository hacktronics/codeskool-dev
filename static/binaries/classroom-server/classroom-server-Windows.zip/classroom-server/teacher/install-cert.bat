@echo off
cd /d "%~dp0"
"codeskool-classroom.exe" --install-cert
pause
