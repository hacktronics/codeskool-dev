from pyodide.ffi import to_js # type: ignore
import PPY_JS # type: ignore

class Sprite:
  def __init__(self, name):
    self.name = name

  def move_steps(self, steps=10):
    PPY_JS.execute(to_js(self.name), to_js("motion_movesteps"), to_js('{"STEPS": ' + str(steps) + '}'))

  def turn_right(self, degrees=15):
    PPY_JS.execute(to_js(self.name), to_js("motion_turnright"), to_js('{"DEGREES": ' + str(degrees) + '}'))

  def turn_left(self, degrees=15):
    PPY_JS.execute(to_js(self.name), to_js("motion_turnleft"), to_js('{"DEGREES": ' + str(degrees) + '}'))

  def goto(self, to="_random_"):
    # to can be "_random_" or "_mouse_"
    PPY_JS.execute(to_js(self.name), to_js("motion_goto"), to_js('{"TO": "' + str(to) + '"}'))

  def goto_xy(self, x=0, y=0):
    PPY_JS.execute(to_js(self.name), to_js("motion_gotoxy"), to_js('{"X": ' + str(x) + ', "Y": ' + str(y) + '}'))