from pyodide.ffi import to_js # type: ignore
import PPY_JS # type: ignore

__SPRITE_NAME__ = "CodeSkool_Sprite"
__IS_STAGE__ = False

class Sprite:
  def __init__(self):
    pass

  def move_steps(self, steps=10):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("motion_movesteps"), to_js('{"STEPS": ' + str(steps) + '}'))

  def turn_right(self, degrees=15):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("motion_turnright"), to_js('{"DEGREES": ' + str(degrees) + '}'))

  def turn_left(self, degrees=15):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("motion_turnleft"), to_js('{"DEGREES": ' + str(degrees) + '}'))

  def goto(self, to="_random_"):
    # to can be "_random_" or "_mouse_"
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("motion_goto"), to_js('{"TO": "' + str(to) + '"}'))

  def goto_xy(self, x=0, y=0):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("motion_gotoxy"), to_js('{"X": ' + str(x) + ', "Y": ' + str(y) + '}'))


class Pen:
  def __init__(self):
    pass

  def down(self):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_penDown"), to_js('{}'))

  def up(self):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_penUp"), to_js('{}'))

  def clear(self):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_clear"), to_js('{}'))

  def stamp(self):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_stamp"), to_js('{}'))

  def set_color(self, COLOR=[0,0,0]):
    if isinstance(COLOR, str):
      PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_setPenColorToColor"), to_js('{"COLOR": "' + str(COLOR) + '"}'))
    else:
      PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_setPenColorToColor"), to_js('{"COLOR": ' + str(COLOR) + '}'))

  def change_color(self, COLOR_PARAM="color", VALUE=10):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_changePenColorParamBy"), to_js('{"COLOR_PARAM": "' + str(COLOR_PARAM) + '", "VALUE": ' + str(VALUE) + '}'))

  def set_size(self, SIZE=1):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_setPenSizeTo"), to_js('{"SIZE": ' + str(SIZE) + '}'))

  def change_size(self, SIZE=1):
    PPY_JS.execute(to_js(__SPRITE_NAME__), to_js("pen_changePenSizeBy"), to_js('{"SIZE": ' + str(SIZE) + '}'))
